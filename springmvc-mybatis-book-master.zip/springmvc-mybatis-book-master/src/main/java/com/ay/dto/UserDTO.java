package com.ay.dto;

import com.ay.model.User;

/**
 * 描述：用户DTO
 *
 * @author Ay
 * @create 2018/07/01
 **/
public class UserDTO extends User {

}
