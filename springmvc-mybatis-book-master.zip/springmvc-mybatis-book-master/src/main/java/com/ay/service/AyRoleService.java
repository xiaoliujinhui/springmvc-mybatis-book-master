package com.ay.service;

import com.ay.model.AyRole;

public interface AyRoleService {
    AyRole findById(String id);
}
