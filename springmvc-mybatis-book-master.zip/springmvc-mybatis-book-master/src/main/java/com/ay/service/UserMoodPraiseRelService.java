package com.ay.service;

import com.ay.model.UserMoodPraiseRel;

/**
 * 描述：用户说说点赞关联接口
 *
 * @author Ay
 * @date 2018/1/6.
 */
public interface UserMoodPraiseRelService {

    boolean save(UserMoodPraiseRel userMoodPraiseRel);
}
