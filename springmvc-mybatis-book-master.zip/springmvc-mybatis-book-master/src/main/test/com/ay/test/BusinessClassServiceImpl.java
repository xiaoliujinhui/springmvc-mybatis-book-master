package com.ay.test;

import org.springframework.stereotype.Service;

/**
 * 描述：业务实现类
 *
 * @author Ay
 * @create 2018/04/22
 **/
public class BusinessClassServiceImpl implements BusinessClassService {

    /**
     * 处理业务
     */
    public void doSomeThing() {
        System.out.println("do something ......");
    }
}
