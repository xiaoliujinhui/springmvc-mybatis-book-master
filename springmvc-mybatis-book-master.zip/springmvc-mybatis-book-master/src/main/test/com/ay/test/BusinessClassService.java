package com.ay.test;

/**
 * 描述：业务类接口
 *
 * @author Ay
 * @create 2018/04/22
 **/
public interface BusinessClassService {

    void doSomeThing();
}
